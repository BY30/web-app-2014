var fs = require('fs');
var Database = require('../../../lib/database.js');
var db = new Database();

function decodeBase64Image(dataString) {
  var matches = dataString.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/),
    response = {};

  if (matches.length !== 3) {
    return new Error('Invalid input string');
  }

  response.type = matches[1];
  response.data = new Buffer(matches[2], 'base64');

  return response;
}

db.getSection('speakers', function (err, data) {

	for (var j = 0; j < data[0].data.length; j++) {
		var members = data[0].data[j].speakers;
		console.log('Processing session ' + data[0].data[j].date);
		var dirname = data[0].data[j].date;
		dirname = dirname.split(' ')[0].toLowerCase().substring(0,3) + dirname.split(' ')[1];
		console.log('Creating folder ' + dirname);
		//fs.mkdirSync(dirname);
		for (var i = 0; i < members.length; i++) {
			//var image = decodeBase64Image(members[i].photo);
			//console.log("Saving image for " + members[i].name + " as " + members[i].id + ".jpg...");
			var filename = dirname + '/' + members[i].id + '.jpg';
		//	fs.writeFileSync(filename, image.data);
			members[i].photo = '/images/speakers/' + filename;
		};
	}

	var newData = data[0].toObject();
	delete newData._id;

	db.updateContent('speakers', newData, function (err) {});

});
